<?php

/* @var $factory \Illuminate\Database\Eloquent\Factory */

use App\cart;
use Faker\Generator as Faker;

$factory->define(cart::class, function (Faker $faker) {
    return [
        //
    ];
});
