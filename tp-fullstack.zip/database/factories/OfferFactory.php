<?php

/* @var $factory \Illuminate\Database\Eloquent\Factory */

use App\offer;
use Faker\Generator as Faker;

$factory->define(offer::class, function (Faker $faker) {
    return [
        //
    ];
});
