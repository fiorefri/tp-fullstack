<?php

/* @var $factory \Illuminate\Database\Eloquent\Factory */

use App\product;
use Faker\Generator as Faker;

$factory->define(product::class, function (Faker $faker) {
    return [
        //
    ];
});
