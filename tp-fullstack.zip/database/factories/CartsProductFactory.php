<?php

/* @var $factory \Illuminate\Database\Eloquent\Factory */

use App\cartsProduct;
use Faker\Generator as Faker;

$factory->define(cartsProduct::class, function (Faker $faker) {
    return [
        //
    ];
});
