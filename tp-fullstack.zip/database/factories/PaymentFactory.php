<?php

/* @var $factory \Illuminate\Database\Eloquent\Factory */

use App\payment;
use Faker\Generator as Faker;

$factory->define(payment::class, function (Faker $faker) {
    return [
        //
    ];
});
